//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    println("Введите Имя оператора")
    val y = Yota(readln())
    y.Input()

    println("Введите Имя оператора")
    val m = Motiv(readln())
    m.Input()
    println("Хотите переименовать оператор")
    if (readln() == "да"){
        m.Rename()
    }
    y.Print()
    m.Print()
}