class Motiv(name:String) : Yota(name){
    override var Name = name
    override var Min = 0.0
    override var S = 0.0
    override var P = false
    fun Rename(){
        println("Введите новое имя")
        Name = readln()
    }
}