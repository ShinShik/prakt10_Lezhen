interface inter {
    fun Input()
    fun Print()
    fun Qp(p:Boolean):Double
    fun Q(s:Double,min:Double):Double
}