abstract class abstr (name:String) : inter {
    open var Name = name
    abstract var Min:Double
    abstract var S:Double
    abstract var P:Boolean
    override fun Input() {
        println(
            "Введите:\n" +
                    "Стоимость за 1 минуту\n" +
                    "Площадь покрытия\n" +
                    "Есть ли оплата за каждое соединение?(да/нет)"
        )
    }
    override fun Print() {
        println("Оператора: $Name\n" +
                "Стоимость за минуту: $Min\n" +
                "Площадь покрытия: $S\n" +
                "Q = ${Q(S,Min)}\n" +
                "Qp = ${Qp(P)} (при P = $P)"
        )
    }
    override fun Qp(p:Boolean):Double {
        return 0.0
    }
    override fun Q(s:Double,min:Double):Double {
        return 0.0
    }
}